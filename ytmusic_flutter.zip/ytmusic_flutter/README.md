# YT Music (Open Source) — Flutter Client

An unofficial, open-source YouTube Music client for Android, built with Flutter.
Streams audio directly from YouTube and authenticates against your account
using a pasted browser cookie (no OAuth app registration needed).

**This is not affiliated with or endorsed by Google/YouTube.** It talks to
YouTube's private, undocumented "innertube" web API (the same one
music.youtube.com's own website uses), which can change at any time.

## Features

- Home feed: quick picks, recently played, your library playlists
- Search for songs
- Background playback with lock-screen / notification media controls
  (play, pause, skip, seek) via `audio_service` + `just_audio`
- Expandable "Now Playing" sheet with shuffle/repeat
- Cookie-based login stored in encrypted on-device secure storage

## Getting your cookie (one-time setup, per device)

1. On a desktop browser, log in at `https://music.youtube.com`.
2. Install a cookie-export extension, e.g. **"Get cookies.txt LOCALLY"** or
   **"EditThisCookie"**.
3. Export/copy the cookies for `music.youtube.com` as a single **Cookie
   header string** — a `Name=Value; Name2=Value2; ...` line. It must include
   `SAPISID` (or `__Secure-3PAPISID`) and `SID`.
4. Open the app → **Settings** → paste the string into the cookie box →
   **Save cookie**.

Your cookie never leaves your device except in direct requests to YouTube's
own servers — nothing is sent to any third-party backend.

## Getting the APK without compiling anything yourself

This repo ships a GitHub Actions workflow at `.github/workflows/build.yml`
that automatically:

1. Installs Flutter on GitHub's servers.
2. Runs `flutter build apk --release`.
3. Uploads the resulting APK both as a **workflow build artifact** and as a
   **GitHub Release** attachment.

To use it:

1. Push this project to a GitHub repository (see below).
2. Go to your repo's **Actions** tab and watch the "Build Android APK" run.
3. When it finishes, either:
   - Open the run → scroll to **Artifacts** → download `app-release-apk`, or
   - Go to your repo's **Releases** page → download `app-release.apk` from
     the latest release.
4. Transfer the `.apk` to your Android phone and open it to install
   (you'll need to allow "Install unknown apps" for whichever app you use
   to open it — Files, Chrome, etc.).

### Pushing this project to GitHub for the first time

```bash
cd ytmusic_flutter
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

The workflow triggers automatically on every push to `main`/`master`, and
can also be run manually from the Actions tab ("Run workflow" button).

## Project structure

```
lib/
  main.dart                  # App entry point, wires up audio_service
  theme/app_theme.dart       # Dark theme
  models/                    # Song, Playlist, HomeSection
  services/
    auth_service.dart        # Encrypted cookie storage
    sapisid_hash.dart        # Computes the SAPISIDHASH auth header
    ytmusic_api.dart          # Calls YT Music's internal browse/search API
    stream_resolver.dart     # Resolves playable audio URLs via youtube_explode_dart
    my_audio_handler.dart    # audio_service <-> just_audio bridge
  providers/player_provider.dart
  screens/                   # Home, Search, Settings, Player sheet, Root shell
  widgets/                   # SongTile, PlaylistCard, MiniPlayer
android/                     # Native Android project (permissions, manifest)
.github/workflows/build.yml  # CI: builds & publishes the APK
```

## Known limitations / things to expect

- YouTube's internal API responses are deeply nested and undocumented.
  The parsers in `ytmusic_api.dart` are written defensively (they skip
  anything they can't parse instead of crashing), but if Home or Search
  ever come back empty, it usually means Google tweaked the response shape
  and a JSON path in that file needs a small update.
- The release APK is built with the **debug signing key** so it installs
  with zero setup. If you ever want to publish this to the Play Store,
  generate your own upload keystore and wire it into
  `android/app/build.gradle` first.
- No iOS build is configured (YouTube Music clients like this one live in
  a legal gray area App Store review does not allow; Android sideloading
  does).
