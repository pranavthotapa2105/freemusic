import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_service.dart';
import 'sapisid_hash.dart';
import '../models/song.dart';
import '../models/playlist.dart';

/// A lightweight client for YouTube Music's internal "innertube" JSON API —
/// the same private API that music.youtube.com's own web player uses, and
/// that the Python `ytmusicapi` project reverse-engineered. There is no
/// official public API for this data, so this talks directly to:
///
///   https://music.youtube.com/youtubei/v1/<endpoint>
///
/// with a browser-shaped request body/context, plus your account cookies
/// and a SAPISIDHASH signature so requests are treated as authenticated.
class YtMusicApi {
  static const _baseUrl = 'https://music.youtube.com/youtubei/v1';
  static const _origin = 'https://music.youtube.com';

  // Public, unauthenticated key used by the YT Music web client itself.
  // This is not a secret — it ships in every music.youtube.com page load.
  static const _apiKey = 'AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30';

  final http.Client _client = http.Client();

  Map<String, dynamic> _baseContext() => {
        'context': {
          'client': {
            'clientName': 'WEB_REMIX',
            'clientVersion': '1.20240101.01.00',
            'hl': 'en',
            'gl': 'US',
          },
          'user': {'lockedSafetyMode': false},
        },
      };

  Future<Map<String, String>> _headers() async {
    final cookie = await AuthService.instance.getCookie();
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'X-Goog-Visitor-Id': '',
      'Origin': _origin,
      'Referer': '$_origin/',
      'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
    };

    if (cookie != null && cookie.isNotEmpty) {
      headers['Cookie'] = cookie;
      headers['X-Goog-AuthUser'] = '0';
      final auth = SapisidHash.buildAuthorizationHeader(cookie, _origin);
      if (auth != null) headers['Authorization'] = auth;
    }

    return headers;
  }

  Future<Map<String, dynamic>> _post(
    String endpoint,
    Map<String, dynamic> extraBody,
  ) async {
    final uri = Uri.parse('$_baseUrl/$endpoint?key=$_apiKey&prettyPrint=false');
    final body = {..._baseContext(), ...extraBody};
    final response = await _client.post(
      uri,
      headers: await _headers(),
      body: jsonEncode(body),
    );

    if (response.statusCode != 200) {
      throw Exception(
          'YT Music API error on $endpoint: ${response.statusCode} ${response.body}');
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  // ---------------------------------------------------------------------
  // SEARCH
  // ---------------------------------------------------------------------

  Future<List<Song>> search(String query) async {
    final json = await _post('search', {
      'query': query,
      // "Songs" search filter param, as used by music.youtube.com.
      'params': 'EgWKAQIIAWoKEAMQBBAJEAoQBQ%3D%3D',
    });

    final results = <Song>[];
    try {
      final contents = _findFirstList(json, 'musicResponsiveListItemRenderer');
      for (final item in contents) {
        final song = _parseResponsiveListItem(item);
        if (song != null) results.add(song);
      }
    } catch (_) {
      // YouTube occasionally reshapes search responses; fail soft rather
      // than crash the search screen.
    }
    return results;
  }

  // ---------------------------------------------------------------------
  // HOME FEED (quick picks / recently played / mixes)
  // ---------------------------------------------------------------------

  Future<List<HomeSection>> getHome() async {
    final json = await _post('browse', {'browseId': 'FEmusic_home'});
    final sections = <HomeSection>[];

    try {
      final shelves = _findAllByKey(json, 'musicCarouselShelfRenderer');
      for (final shelf in shelves) {
        final headerTitle = _digString(shelf,
                ['header', 'musicCarouselShelfBasicHeaderRenderer', 'title', 'runs', 0, 'text']) ??
            'Recommended';

        final items = (shelf['contents'] as List?) ?? [];
        final songs = <Song>[];
        final playlists = <MusicPlaylist>[];

        for (final item in items) {
          if (item is! Map<String, dynamic>) continue;
          if (item.containsKey('musicResponsiveListItemRenderer')) {
            final song = _parseResponsiveListItem(
                item['musicResponsiveListItemRenderer']);
            if (song != null) songs.add(song);
          } else if (item.containsKey('musicTwoRowItemRenderer')) {
            final playlist =
                _parseTwoRowItem(item['musicTwoRowItemRenderer']);
            if (playlist != null) playlists.add(playlist);
          }
        }

        if (songs.isNotEmpty || playlists.isNotEmpty) {
          sections.add(HomeSection(
              title: headerTitle, songs: songs, playlists: playlists));
        }
      }
    } catch (_) {
      // Fail soft — return whatever sections were parsed so far.
    }

    return sections;
  }

  // ---------------------------------------------------------------------
  // LIBRARY PLAYLISTS (requires auth cookie)
  // ---------------------------------------------------------------------

  Future<List<MusicPlaylist>> getLibraryPlaylists() async {
    final json = await _post('browse', {'browseId': 'FEmusic_liked_playlists'});
    final playlists = <MusicPlaylist>[];
    try {
      final items = _findAllByKey(json, 'musicTwoRowItemRenderer');
      for (final item in items) {
        final playlist = _parseTwoRowItem(item);
        if (playlist != null) playlists.add(playlist);
      }
    } catch (_) {}
    return playlists;
  }

  Future<MusicPlaylist> getPlaylist(String playlistId) async {
    final normalizedId =
        playlistId.startsWith('VL') ? playlistId : 'VL$playlistId';
    final json = await _post('browse', {'browseId': normalizedId});

    String title = 'Playlist';
    try {
      title = _digString(json, [
            'header',
            'musicDetailHeaderRenderer',
            'title',
            'runs',
            0,
            'text'
          ]) ??
          title;
    } catch (_) {}

    final songs = <Song>[];
    try {
      final items = _findAllByKey(json, 'musicResponsiveListItemRenderer');
      for (final item in items) {
        final song = _parseResponsiveListItem(item);
        if (song != null) songs.add(song);
      }
    } catch (_) {}

    return MusicPlaylist(
      playlistId: playlistId,
      title: title,
      thumbnailUrl: songs.isNotEmpty ? songs.first.thumbnailUrl : '',
      songs: songs,
    );
  }

  // ---------------------------------------------------------------------
  // Parsing helpers
  //
  // YT Music's internal JSON is deeply nested and undocumented. These
  // helpers walk the tree defensively (returning null instead of throwing)
  // because the exact shape can vary slightly between shelf types and can
  // change without notice on Google's side.
  // ---------------------------------------------------------------------

  Song? _parseResponsiveListItem(Map<String, dynamic> item) {
    try {
      final videoId = _digString(item, ['playlistItemData', 'videoId']) ??
          _digString(item, [
            'overlay',
            'musicItemThumbnailOverlayRenderer',
            'content',
            'musicPlayButtonRenderer',
            'playNavigationEndpoint',
            'watchEndpoint',
            'videoId'
          ]);
      if (videoId == null) return null;

      final flexColumns = item['flexColumns'] as List? ?? [];
      String title = 'Unknown title';
      String artist = 'Unknown artist';

      if (flexColumns.isNotEmpty) {
        title = _digString(flexColumns[0], [
              'musicResponsiveListItemFlexColumnRenderer',
              'text',
              'runs',
              0,
              'text'
            ]) ??
            title;
      }
      if (flexColumns.length > 1) {
        final runs = _dig(flexColumns[1],
            ['musicResponsiveListItemFlexColumnRenderer', 'text', 'runs']);
        if (runs is List && runs.isNotEmpty) {
          artist = runs
              .map((r) => (r is Map && r['text'] is String) ? r['text'] : '')
              .where((t) => t.toString().trim().isNotEmpty)
              .join(' ');
          if (artist.isEmpty) artist = 'Unknown artist';
        }
      }

      final thumbnails = _dig(item, ['thumbnail', 'musicThumbnailRenderer', 'thumbnail', 'thumbnails']);
      String thumbUrl = '';
      if (thumbnails is List && thumbnails.isNotEmpty) {
        thumbUrl = thumbnails.last['url'] ?? '';
      }

      return Song(
        videoId: videoId,
        title: title,
        artist: artist,
        thumbnailUrl: thumbUrl,
      );
    } catch (_) {
      return null;
    }
  }

  MusicPlaylist? _parseTwoRowItem(Map<String, dynamic> item) {
    try {
      final playlistId = _digString(item, [
            'navigationEndpoint',
            'browseEndpoint',
            'browseId'
          ]) ??
          '';
      if (playlistId.isEmpty) return null;

      final title = _digString(item, ['title', 'runs', 0, 'text']) ?? 'Playlist';
      final subtitle = _digString(item, ['subtitle', 'runs', 0, 'text']);

      final thumbnails = _dig(
          item, ['thumbnailRenderer', 'musicThumbnailRenderer', 'thumbnail', 'thumbnails']);
      String thumbUrl = '';
      if (thumbnails is List && thumbnails.isNotEmpty) {
        thumbUrl = thumbnails.last['url'] ?? '';
      }

      return MusicPlaylist(
        playlistId: playlistId.replaceFirst('VL', ''),
        title: title,
        thumbnailUrl: thumbUrl,
        subtitle: subtitle,
      );
    } catch (_) {
      return null;
    }
  }

  dynamic _dig(dynamic node, List<Object> path) {
    dynamic current = node;
    for (final key in path) {
      if (current == null) return null;
      if (key is String && current is Map) {
        current = current[key];
      } else if (key is int && current is List) {
        if (key >= current.length) return null;
        current = current[key];
      } else {
        return null;
      }
    }
    return current;
  }

  String? _digString(dynamic node, List<Object> path) {
    final value = _dig(node, path);
    return value is String ? value : null;
  }

  /// Recursively finds every value in a nested JSON tree keyed by [key],
  /// e.g. every `musicResponsiveListItemRenderer` anywhere in the response.
  List<Map<String, dynamic>> _findAllByKey(dynamic node, String key) {
    final results = <Map<String, dynamic>>[];
    void walk(dynamic n) {
      if (n is Map<String, dynamic>) {
        if (n.containsKey(key) && n[key] is Map<String, dynamic>) {
          results.add(n[key] as Map<String, dynamic>);
        }
        for (final v in n.values) {
          walk(v);
        }
      } else if (n is List) {
        for (final v in n) {
          walk(v);
        }
      }
    }

    walk(node);
    return results;
  }

  List<Map<String, dynamic>> _findFirstList(dynamic node, String key) {
    return _findAllByKey(node, key);
  }

  void dispose() {
    _client.close();
  }
}
