import 'package:http/http.dart' as http;
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'auth_service.dart';

/// Resolves a direct, playable audio stream URL for a given YouTube video ID
/// using `youtube_explode_dart`. The saved account cookie is attached to
/// every request this client makes, which lets age-restricted or
/// account-gated tracks resolve the same way they would in a logged-in
/// browser tab.
class StreamResolver {
  StreamResolver._internal();
  static final StreamResolver instance = StreamResolver._internal();

  YoutubeExplode? _yt;

  Future<YoutubeExplode> _client() async {
    final cookie = await AuthService.instance.getCookie();
    // Dispose and recreate if the cookie changed since last use, so a
    // fresh login/logout takes effect immediately.
    _yt?.close();
    final httpClient = _CookieHttpClient(cookie);
    _yt = YoutubeExplode(YoutubeHttpClient(httpClient));
    return _yt!;
  }

  /// Returns the highest-bitrate audio-only stream URL for [videoId].
  Future<Uri> resolveAudioStreamUrl(String videoId) async {
    final yt = await _client();
    final manifest = await yt.videos.streamsClient.getManifest(videoId);
    final audioStream = manifest.audioOnly.withHighestBitrate();
    return audioStream.url;
  }

  Future<Video> getVideoDetails(String videoId) async {
    final yt = await _client();
    return yt.videos.get(videoId);
  }

  void dispose() {
    _yt?.close();
  }
}

/// A minimal http.Client wrapper that attaches the user's YT Music cookie
/// header to every outgoing request, so youtube_explode_dart resolves
/// streams as the logged-in account rather than anonymously.
class _CookieHttpClient extends http.BaseClient {
  _CookieHttpClient(this._cookie);
  final String? _cookie;
  final http.Client _inner = http.Client();

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    if (_cookie != null && _cookie!.isNotEmpty) {
      request.headers['cookie'] = _cookie!;
    }
    return _inner.send(request);
  }
}
