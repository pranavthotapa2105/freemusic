import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Handles securely persisting the user's YouTube Music session cookie
/// string (copied from a browser extension such as "EditThisCookie" /
/// "Get cookies.txt LOCALLY") on-device.
class AuthService {
  AuthService._internal();
  static final AuthService instance = AuthService._internal();

  static const _cookieKey = 'yt_music_cookie';

  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  Future<void> saveCookie(String cookie) async {
    await _storage.write(key: _cookieKey, value: cookie.trim());
  }

  Future<String?> getCookie() async {
    final value = await _storage.read(key: _cookieKey);
    if (value == null || value.trim().isEmpty) return null;
    return value.trim();
  }

  Future<void> clearCookie() async {
    await _storage.delete(key: _cookieKey);
  }

  Future<bool> isLoggedIn() async {
    final cookie = await getCookie();
    return cookie != null && cookie.contains('SAPISID');
  }
}
