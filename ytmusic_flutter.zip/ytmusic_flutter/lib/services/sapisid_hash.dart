import 'dart:convert';
import 'package:crypto/crypto.dart';

/// YouTube's internal ("innertube") JSON API does NOT authenticate you just
/// because you sent the `Cookie` header. For logged-in requests it also
/// expects an `Authorization: SAPISIDHASH <timestamp>_<hash>` header, where
/// the hash is:
///
///   SHA1("<timestamp> <SAPISID cookie value> <origin>")
///
/// This is exactly what youtube.com's own web client does, and what
/// ytmusicapi replicates server-side. Without this header, YouTube Music
/// will silently treat you as a signed-out/anonymous user even though you
/// supplied valid cookies.
class SapisidHash {
  /// Extracts the raw SAPISID value out of a full cookie header string.
  /// Falls back to `__Secure-3PAPISID`, which recent Google cookies also use.
  static String? extractSapisid(String cookieHeader) {
    final cookies = _parseCookies(cookieHeader);
    return cookies['SAPISID'] ?? cookies['__Secure-3PAPISID'];
  }

  static Map<String, String> _parseCookies(String cookieHeader) {
    final map = <String, String>{};
    for (final part in cookieHeader.split(';')) {
      final trimmed = part.trim();
      if (trimmed.isEmpty) continue;
      final eqIndex = trimmed.indexOf('=');
      if (eqIndex == -1) continue;
      final key = trimmed.substring(0, eqIndex).trim();
      final value = trimmed.substring(eqIndex + 1).trim();
      map[key] = value;
    }
    return map;
  }

  /// Builds the full `Authorization` header value.
  /// [origin] should be `https://music.youtube.com` for YT Music calls.
  static String? buildAuthorizationHeader(String cookieHeader, String origin) {
    final sapisid = extractSapisid(cookieHeader);
    if (sapisid == null || sapisid.isEmpty) return null;

    final timestamp = (DateTime.now().millisecondsSinceEpoch / 1000).floor();
    final raw = '$timestamp $sapisid $origin';
    final hash = sha1.convert(utf8.encode(raw)).toString();
    return 'SAPISIDHASH ${timestamp}_$hash';
  }
}
