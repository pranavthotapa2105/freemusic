import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/playlist.dart';
import '../providers/player_provider.dart';
import '../services/ytmusic_api.dart';
import '../theme/app_theme.dart';
import '../widgets/playlist_card.dart';
import '../widgets/song_tile.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final YtMusicApi _api = YtMusicApi();
  List<HomeSection> _sections = [];
  List<MusicPlaylist> _libraryPlaylists = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final home = await _api.getHome();
      final library = await _api.getLibraryPlaylists();
      setState(() {
        _sections = home;
        _libraryPlaylists = library;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final player = context.read<PlayerProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: RefreshIndicator(
        onRefresh: _load,
        color: AppColors.accent,
        backgroundColor: AppColors.surface,
        child: _loading
            ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
            : _error != null
                ? _buildError()
                : ListView(
                    children: [
                      if (_libraryPlaylists.isNotEmpty) ...[
                        _SectionHeader('Your playlists'),
                        _PlaylistShelf(playlists: _libraryPlaylists),
                      ],
                      for (final section in _sections) ...[
                        _SectionHeader(section.title),
                        if (section.playlists.isNotEmpty)
                          _PlaylistShelf(playlists: section.playlists),
                        if (section.songs.isNotEmpty)
                          ...section.songs.map((song) => SongTile(
                                song: song,
                                onTap: () => player.playQueue(section.songs,
                                    startIndex: section.songs.indexOf(song)),
                              )),
                      ],
                      const SizedBox(height: 80),
                    ],
                  ),
      ),
    );
  }

  Widget _buildError() {
    final signedOut = _error!.contains('401') || _error!.contains('403');
    return ListView(
      children: [
        const SizedBox(height: 80),
        Icon(Icons.cloud_off, size: 48, color: AppColors.textSecondary),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Text(
            signedOut
                ? "Couldn't load your feed. Make sure you've pasted a valid, "
                    "logged-in cookie in Settings."
                : "Something went wrong loading Home:\n$_error",
            textAlign: TextAlign.center,
            style: const TextStyle(color: AppColors.textSecondary),
          ),
        ),
        const SizedBox(height: 16),
        Center(
          child: TextButton(onPressed: _load, child: const Text('Retry')),
        ),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
      child: Text(
        title,
        style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 18,
            fontWeight: FontWeight.bold),
      ),
    );
  }
}

class _PlaylistShelf extends StatelessWidget {
  final List<MusicPlaylist> playlists;
  const _PlaylistShelf({required this.playlists});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 190,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: playlists.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final playlist = playlists[index];
          return PlaylistCard(
            playlist: playlist,
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => _PlaylistDetailScreen(playlistId: playlist.playlistId),
              ));
            },
          );
        },
      ),
    );
  }
}

class _PlaylistDetailScreen extends StatefulWidget {
  final String playlistId;
  const _PlaylistDetailScreen({required this.playlistId});

  @override
  State<_PlaylistDetailScreen> createState() => _PlaylistDetailScreenState();
}

class _PlaylistDetailScreenState extends State<_PlaylistDetailScreen> {
  final YtMusicApi _api = YtMusicApi();
  MusicPlaylist? _playlist;

  @override
  void initState() {
    super.initState();
    _api.getPlaylist(widget.playlistId).then((p) {
      if (mounted) setState(() => _playlist = p);
    });
  }

  @override
  Widget build(BuildContext context) {
    final player = context.read<PlayerProvider>();
    return Scaffold(
      appBar: AppBar(title: Text(_playlist?.title ?? 'Playlist')),
      body: _playlist == null
          ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
          : ListView.builder(
              itemCount: _playlist!.songs.length,
              itemBuilder: (context, index) {
                final song = _playlist!.songs[index];
                return SongTile(
                  song: song,
                  onTap: () => player.playQueue(_playlist!.songs, startIndex: index),
                );
              },
            ),
    );
  }
}
