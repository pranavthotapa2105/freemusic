import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _cookieController = TextEditingController();
  bool _loading = true;
  bool _saved = false;
  bool _obscure = true;

  @override
  void initState() {
    super.initState();
    _loadExisting();
  }

  Future<void> _loadExisting() async {
    final cookie = await AuthService.instance.getCookie();
    setState(() {
      _cookieController.text = cookie ?? '';
      _loading = false;
    });
  }

  Future<void> _save() async {
    final value = _cookieController.text.trim();
    if (value.isEmpty) {
      await AuthService.instance.clearCookie();
    } else {
      await AuthService.instance.saveCookie(value);
    }
    setState(() => _saved = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _saved = false);
    });
  }

  Future<void> _logout() async {
    await AuthService.instance.clearCookie();
    setState(() => _cookieController.clear());
  }

  @override
  void dispose() {
    _cookieController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'YouTube Music account',
                  style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Paste your full YouTube Music cookie string below to sign in. '
                  'You can copy this from a browser extension such as '
                  '"Get cookies.txt LOCALLY" or "EditThisCookie" while logged in '
                  'at music.youtube.com — copy the entire Cookie header value '
                  '(it should contain SAPISID and SID among other fields).',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _cookieController,
                  maxLines: _obscure ? 1 : 6,
                  obscureText: _obscure,
                  style: const TextStyle(color: AppColors.textPrimary, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'SAPISID=...; SID=...; HSID=...; ...',
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscure ? Icons.visibility_off : Icons.visibility,
                        color: AppColors.textSecondary,
                      ),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        onPressed: _save,
                        child: Text(_saved ? 'Saved ✓' : 'Save cookie'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.textSecondary,
                        padding: const EdgeInsets.symmetric(
                            vertical: 14, horizontal: 16),
                      ),
                      onPressed: _logout,
                      child: const Text('Log out'),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                const Divider(color: AppColors.surfaceHigh),
                const SizedBox(height: 12),
                const Text(
                  'Your cookie is stored only on this device using encrypted '
                  'secure storage. It is never sent anywhere except directly '
                  'to YouTube\'s own servers to authenticate your requests.',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                ),
              ],
            ),
    );
  }
}
