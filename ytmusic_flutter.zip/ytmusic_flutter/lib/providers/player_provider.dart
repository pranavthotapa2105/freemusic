import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import '../models/song.dart';
import '../services/my_audio_handler.dart';

/// Thin ChangeNotifier wrapper around [MyAudioHandler] so widgets can
/// listen to "what's playing right now" without reaching into audio_service
/// streams directly.
class PlayerProvider extends ChangeNotifier {
  PlayerProvider(this._handler) {
    _handler.mediaItem.listen((item) {
      _currentSong = item == null
          ? null
          : Song(
              videoId: item.id,
              title: item.title,
              artist: item.artist ?? '',
              thumbnailUrl: item.artUri?.toString() ?? '',
              duration: item.duration,
            );
      notifyListeners();
    });

    _handler.playbackState.listen((state) {
      _isPlaying = state.playing;
      _processingState = state.processingState;
      notifyListeners();
    });
  }

  final MyAudioHandler _handler;

  Song? _currentSong;
  bool _isPlaying = false;
  AudioProcessingState _processingState = AudioProcessingState.idle;

  Song? get currentSong => _currentSong;
  bool get isPlaying => _isPlaying;
  AudioProcessingState get processingState => _processingState;
  MyAudioHandler get handler => _handler;

  Stream<Duration> get positionStream => AudioService.position;

  Future<void> playQueue(List<Song> songs, {int startIndex = 0}) =>
      _handler.loadQueue(songs, startIndex: startIndex);

  Future<void> playSingle(Song song) => _handler.loadQueue([song]);

  void togglePlayPause() {
    if (_isPlaying) {
      _handler.pause();
    } else {
      _handler.play();
    }
  }

  void seek(Duration position) => _handler.seek(position);
  void skipNext() => _handler.skipToNext();
  void skipPrevious() => _handler.skipToPrevious();
}
