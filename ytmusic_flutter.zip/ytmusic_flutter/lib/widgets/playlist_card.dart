import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/playlist.dart';
import '../theme/app_theme.dart';

class PlaylistCard extends StatelessWidget {
  final MusicPlaylist playlist;
  final VoidCallback onTap;

  const PlaylistCard({super.key, required this.playlist, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 140,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SizedBox(
                width: 140,
                height: 140,
                child: playlist.thumbnailUrl.isNotEmpty
                    ? CachedNetworkImage(
                        imageUrl: playlist.thumbnailUrl,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => Container(
                          color: AppColors.surfaceHigh,
                          child: const Icon(Icons.queue_music,
                              color: AppColors.textSecondary),
                        ),
                      )
                    : Container(
                        color: AppColors.surfaceHigh,
                        child: const Icon(Icons.queue_music,
                            color: AppColors.textSecondary),
                      ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              playlist.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  color: AppColors.textPrimary, fontWeight: FontWeight.w600),
            ),
            if (playlist.subtitle != null)
              Text(
                playlist.subtitle!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 12),
              ),
          ],
        ),
      ),
    );
  }
}
