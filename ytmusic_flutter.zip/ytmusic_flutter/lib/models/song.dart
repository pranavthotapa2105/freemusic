class Song {
  final String videoId;
  final String title;
  final String artist;
  final String? album;
  final String thumbnailUrl;
  final Duration? duration;

  Song({
    required this.videoId,
    required this.title,
    required this.artist,
    this.album,
    required this.thumbnailUrl,
    this.duration,
  });

  factory Song.fromJson(Map<String, dynamic> json) {
    return Song(
      videoId: json['videoId'] ?? '',
      title: json['title'] ?? 'Unknown title',
      artist: json['artist'] ?? 'Unknown artist',
      album: json['album'],
      thumbnailUrl: json['thumbnailUrl'] ?? '',
      duration: json['durationSeconds'] != null
          ? Duration(seconds: json['durationSeconds'])
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'videoId': videoId,
        'title': title,
        'artist': artist,
        'album': album,
        'thumbnailUrl': thumbnailUrl,
        'durationSeconds': duration?.inSeconds,
      };
}
