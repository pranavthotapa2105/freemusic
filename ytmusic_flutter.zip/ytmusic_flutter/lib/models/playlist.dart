import 'song.dart';

class MusicPlaylist {
  final String playlistId;
  final String title;
  final String thumbnailUrl;
  final String? subtitle;
  final List<Song> songs;

  MusicPlaylist({
    required this.playlistId,
    required this.title,
    required this.thumbnailUrl,
    this.subtitle,
    this.songs = const [],
  });
}

/// A generic horizontal shelf of items shown on the Home screen
/// (e.g. "Quick picks", "Recently played", "Mixed for you").
class HomeSection {
  final String title;
  final List<Song> songs;
  final List<MusicPlaylist> playlists;

  HomeSection({
    required this.title,
    this.songs = const [],
    this.playlists = const [],
  });
}
