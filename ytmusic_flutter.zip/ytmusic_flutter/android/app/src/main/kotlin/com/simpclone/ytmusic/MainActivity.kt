package com.simpclone.ytmusic

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity()
